public class Program_7 {
    
}
