class Example {  
  
    public static void main(String[] args) {  
         int a = Integer.parseInt(null);

    }  
  
}  