package Calculator;

interface iCalc{
    public void doCalculation();
    public void getResult();
}