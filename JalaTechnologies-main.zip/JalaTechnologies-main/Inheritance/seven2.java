class Animal{  
    void eat(){System.out.println("eating...");}  
    }  
    class Dog{  
    void bark(){System.out.println("barking...");}  
    }  
    class seven2{  
    public static void main(String args[]){  
    Animal ani = new Animal();
    Dog d=new Dog();  
    d.bark();  
    ani.eat();  
    }}  