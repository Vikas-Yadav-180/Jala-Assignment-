import java.lang.reflect.AnnotatedArrayType;

interface interface1{  
    void print(); 
    }  
    interface interface2{
        void boy(); 
        } 
    class ten4 implements interface1{  
    public void print(){System.out.println("Hello");}  
    public void boy(){System.out.println("Boys");} 
    public static void main(String args[]){  
    ten1 obj = new ten1();  
    obj.print();
    obj.boy();
     }  
    } 