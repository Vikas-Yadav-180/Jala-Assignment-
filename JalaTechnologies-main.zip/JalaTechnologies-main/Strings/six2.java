public class six2{
    public static void main(String args[]){
    String s1="hello";
    s1=s1.concat("how are you");
    System.out.println(s1);
    }}