public class six13 {
    public static void main(String args[]) {
        String S1 = new String("UPPERCASE CONVERTED TO LOWERCASE");
        //Convert to LowerCase
        System.out.println(S1.toLowerCase());

    }
}