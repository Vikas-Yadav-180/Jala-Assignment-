import java.util.*;
import java.io.*;
import java.lang.String;
class six1 {
    public static void main(String[] args) 
    {
        String s="Welcome"; // first way to create string
        String s1=new String("data");    // second way to create string using new keyword.
        System.out.println(s);
        System.out.println(s1);

    }
}