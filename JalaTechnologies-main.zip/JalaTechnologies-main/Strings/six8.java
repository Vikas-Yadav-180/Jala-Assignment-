// Java program to demonstrate working
// of java string trim() method
import java.lang.*;
class six8 {
	
	// driver code
	public static void main(String args[])
	{
		
	// trims the trailing and leading spaces
	String s = " geeks for geeks has all java functions to read ";
	System.out.println(s.trim());
	
	// trims the leading spaces
	s = " Chetna loves reading books";
	System.out.println(s.trim());
	
	
	}
}
