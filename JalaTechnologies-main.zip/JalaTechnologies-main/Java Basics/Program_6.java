public class Program_6 {
    public static void main(String[] args) {
        String a="nikhil" ;
        myname(a);
    }
    public static void myname(String a){
        
       System.out.print(a);
        
    }
}
