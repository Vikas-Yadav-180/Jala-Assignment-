public class Program_1 {  //class

    public static void main(String[] args) {
        myMethod();
      }

        static void myMethod() {     //method
          System.out.println("method got executed");
        }
      
        
      }
      

