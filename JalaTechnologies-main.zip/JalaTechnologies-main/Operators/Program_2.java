public class Program_2 {
    public static void main(String[] args) {
        int x = 2 , y = 3 ;
        x++ ;
        y-- ;
        System.out.println(x);
        System.out.println(y);
    }
}
