public class Program_4 {
    public static void main(String[] args) {
        int x=20 , y=20 ;
        if(x == y){
        System.out.println("Both are equal");
        }
        else{
            System.out.println("Not equal");
        }
    }
}
