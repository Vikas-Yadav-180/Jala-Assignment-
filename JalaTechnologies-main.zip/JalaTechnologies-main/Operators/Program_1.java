public class Program_1 {
    public static void main(String[] args) {
        int x=12 , y=6 , z ;
        System.out.println("Sum = "+(x+y));
        System.out.println("Sub = "+(x-y));
        System.out.println("Mul = "+(x*y));
        System.out.println("Div = "+(x/y));

    }
}
