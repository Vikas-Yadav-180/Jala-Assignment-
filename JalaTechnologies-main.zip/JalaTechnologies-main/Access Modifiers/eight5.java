class A{  
    public void msg(){System.out.println("Hello");}  
    }  

    class eight5{  
        public static void main(String args[]){  
         A obj = new A();  
         obj.msg();  
        }  
      }  