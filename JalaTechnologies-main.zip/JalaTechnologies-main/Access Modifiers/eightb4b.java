
package mypack;  
import pack.*;  
  
class eight4b extends A{  
  public static void main(String args[]){  
   B obj = new B();  
   obj.msg();  
  }  
}  