public class Constructor_4 {
    int Constructor_4()
    {
        System.out.println("This will give an eror");
    }
    String Constructor_4()
    {
        System.out.println("This will give an eror");
    }
    public static void main(String[] args) {
        Constructor_4 x=new Constructor_4();
        Constructor_4 x=new Constructor_4();

    }
}
