else{
    //     System.out.println("not a valid case");
    // }