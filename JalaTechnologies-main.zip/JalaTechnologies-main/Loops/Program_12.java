import java.util.*;

public class Program_12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String x =sc.next();
        //System.out.println(x);
        
        switch(x){
            case "m" :
            System.out.println("Male");
            break ;
            case "f" :
            System.out.println("Female");
            break ;
        }
    
   
    }
}
