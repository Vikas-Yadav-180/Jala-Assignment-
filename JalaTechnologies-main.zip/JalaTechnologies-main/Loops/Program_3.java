import javax.print.attribute.standard.PrinterLocation;

public class Program_3 {
    public static void main(String[] args) {
        int x=20 , y=20 ;
        if(x == y){
        System.out.println("x");
        }
        else{
            System.out.println("y");
        }
        int z=30 ;
        if(x != z){
            System.out.println("z");  
        }
        else{
        System.out.println("x");
    }}
}
