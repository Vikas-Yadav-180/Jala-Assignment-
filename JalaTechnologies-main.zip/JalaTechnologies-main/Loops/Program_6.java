public class Program_6 {
    public static void main(String[] args) {
        int x=11 ; 
        while(x<100){
            if(x%2==0){
                System.out.println(x);
                
            }
            x++ ;
        }
    }
}
