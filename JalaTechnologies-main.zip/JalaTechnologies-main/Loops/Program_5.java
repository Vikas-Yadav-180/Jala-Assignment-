public class Program_5 {
   public static void main(String[] args) {
       int x=20 , y=50, z=2 ;
       if(x>y && x>z){
           System.out.print("x is greater");
       }
       else if (y>x && y>z){
        System.out.print("y is greater");
       }
       else{
        System.out.print("z is greater");
       }
   } 
}
